#*************************************************************************
#*************************************************************************
# This python script auto batch generates Osmose Weekly Work Packet Maps
# Client: SOLO
# Inputs: MXD map, work packets csv file
# Output: Individual maps of each work packet and a merged PDF with all maps.
# Python version: 2.6.5
# Script Version: 1.0  Previn Wong 4/19/2011
#*************************************************************************
#*************************************************************************

# import the required libraries
import arcpy, os, csv

#*********** Begin User Specified Params **********************************
#*********** Edit this Portion ********************************************
Claim_CSV_Files = "LA_175 2008.csv,LA_175 2009.csv,LA_175 2010.csv"
Claim_Struct_Check = "4446513E,4446514E,4446515E"
#**************************************************************************
#*********** End User Specified Params ************************************

#*********** Begin MXD setup **********************************
# Specify output path and final output PDF
outPath = r"C:\TEMP\SOLO_Map\claim map\\"
finalPdf = arcpy.mapping.PDFDocumentCreate(outPath + "ClaimReport.pdf")


Pole_Template_shp = "C:\\TEMP\\SOLO_Map\\claim map\\shapefile\\Pole_Template.shp"

csvFile = Claim_CSV_Files.split(",")
for curFile in csvFile:



	mxd = arcpy.mapping.MapDocument(r"C:\TEMP\SOLO_Map\claim map\Claim_maps.mxd")
	df = arcpy.mapping.ListDataFrames(mxd, "Layers")[0]

	fc_All_Poles = arcpy.mapping.ListLayers(mxd, "all_pole_2011", df)[0]
	fc_Select_poles = arcpy.mapping.ListLayers(mxd, "Poles", df)[0]


    	print "Processing " + curFile;

    	print "Join"
    	# Process: Add Join
    	arcpy.AddJoin_management(fc_All_Poles, "NUMBER", curFile, "Original_Structure_Number", "KEEP_COMMON")

    	print "delete"
    	# Process: Delete Features
    	arcpy.Delete_management(Pole_Template_shp, "ShapeFile")

    	print "append"
    	# Process: Append
    	arcpy.CopyFeatures_management(fc_All_Poles, Pole_Template_shp, "", "0", "0", "0")

    	print "Remove Join"
    	arcpy.RemoveJoin_management(fc_All_Poles, curFile)
    
    
    	del mxd, df, fc_All_Poles, fc_Select_poles
    
    
    
    
    
    
	mxd = arcpy.mapping.MapDocument(r"C:\TEMP\SOLO_Map\claim map\Claim_maps.mxd")
	df = arcpy.mapping.ListDataFrames(mxd, "Layers")[0]

	fc_All_Poles = arcpy.mapping.ListLayers(mxd, "all_pole_2011", df)[0]
	fc_Select_poles = arcpy.mapping.ListLayers(mxd, "Poles", df)[0]    
    
    	# Refresh thte view to make sure changes take place.
    	arcpy.RefreshActiveView()    
 	
    	arrStruct = Claim_Struct_Check.split(",")
    	arcpy.SelectLayerByAttribute_management(fc_Select_poles, "NEW_SELECTION", "\"Original_S\" = '" + arrStruct[0] + "'")
    	df.zoomToSelectedFeatures()
    	arcpy.SelectLayerByAttribute_management(fc_Select_poles, "CLEAR_SELECTION")

    	print "generating map"
    	#Export each theme to a temporary PDF and append to the final PDF
    	tmpPdf = outPath + curFile.replace(".", "_") + ".pdf"
    	if os.path.exists(tmpPdf):
            	os.remove(tmpPdf)
    	arcpy.mapping.ExportToPDF(mxd, tmpPdf)
     
    	del tmpPdf, mxd, df, fc_All_Poles, fc_Select_poles
    
    	print "Completed PDF of " + curFile



    
#
raw_input("Press ENTER to exit")

